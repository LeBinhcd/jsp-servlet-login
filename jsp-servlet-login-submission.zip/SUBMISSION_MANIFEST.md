﻿# Submission manifest

This package contains the complete Maven Webapp project.

Required files:
- pom.xml
- src/main/java/com/codegym/LoginServlet.java
- src/main/webapp/index.jsp
- src/main/webapp/WEB-INF/web.xml
- README.md

Build command: mvn clean package
